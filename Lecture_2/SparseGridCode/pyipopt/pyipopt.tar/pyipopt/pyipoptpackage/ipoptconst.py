"""
These are some constants.
"""

# http://www.coin-or.org/Ipopt/documentation/node35.html
# FIXME: these are not actually constant but may be changed within ipopt
NLP_LOWER_BOUND_INF = -1e19
NLP_UPPER_BOUND_INF = 1e19
